function functionOne() {
 var x = document.getElementById("waves");
x.style.height = "200px";
x.style.justifyContent = "center";
x.style.alignItems = "center";
x.style.display = "flex";
var z = document.getElementById("waves")
var y = document.createElement("IMG");
y.setAttribute("src","download.jpg");
z.appendChild(y)
// cant background is set whole while image is PTImageIOFormatBasicMetaColorspaceModelInfoKey
// look up tonight on ow to center this image :)

//https://www.google.com/imgres?imgurl=https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/South_Shetland-2016-Deception_Island%25E2%2580%2593Chinstrap_penguin_%2528Pygoscelis_antarctica%2529_04.jpg/1200px-South_Shetland-2016-Deception_Island%25E2%2580%2593Chinstrap_penguin_%2528Pygoscelis_antarctica%2529_04.jpg&imgrefurl=https://en.wikipedia.org/wiki/Penguin&h=1800&w=1200&tbnid=RfMvtaVaDFvCRM:&tbnh=186&tbnw=124&usg=__wHdLgI2QV1Uldu59hfkxXUGb87E%3D&vet=1&docid=_b7JdMFYrHxY7M&itg=1&sa=X&ved=0ahUKEwjJn7X8xsTZAhUUzGMKHVvfBAwQ_B0I_wEwFQ
}

var bodyback = document.getElementById("body");
var array = ["\"red\"","\"green\"","\"blue\"","\"yellow\"","\"black\""]
let red = array[0]; 
let green = array[1]
let blue = array[2]
let yellow = array[3]
let black = array[4]
let k = 2
console.log(red)
// setInterval(cap, 6000);
//function cap(setInterval(6000)){
//while (k >= 1){
function z() {
var r = 1
//Math.floor(Math.random()*6);
console.log(r);
if (r == 1){bodyback.style.backgroundColor = "\"(red)\"" ;
console.log('this is it');
//works with  quotes? }
}
if (r == 2){bodyback.style.backgroundColor = green;
console.log('this is not it')
}
if (r == 3){bodyback.style.backgroundColor = blue}
if (r == 4){bodyback.style.backgroudColor = yellow}
if (r == 5){bodyback.style.backgroudColor = black}
}
console.log(z())
// }
//}
//console.log(cap())
